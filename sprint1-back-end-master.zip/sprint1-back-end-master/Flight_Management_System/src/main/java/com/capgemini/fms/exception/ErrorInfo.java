package com.capgemini.fms.exception;

public class ErrorInfo {
	private String messgae;

	public ErrorInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ErrorInfo(String messgae) {
		super();
		this.messgae = messgae;
	}

	public String getMessgae() {
		return messgae;
	}

	public void setMessgae(String messgae) {
		this.messgae = messgae;
	}

}
